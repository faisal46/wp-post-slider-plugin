<?php

/*
Plugin Name: RajTech WP Slider
Plugin URI: www.rajtechbd.com
Description: WordPress Slider.
Version: 1.0
Author: RajTech
Author URI: www.faisal.rajtechbd.com
License: GPLv2 or later
Text Domain: rtechts
Domain Path: /langusges/
*/
function rtech_tiny_load_text_domain(){
    load_textdomain('rtechts', false, dirname(__FILE__) . "/languages");
}
add_action('plugins_loaded', 'rtech_tiny_load_text_domain');

function rtech_tiny_image_size(){
    add_image_size('rtech-slider-image-size', 800, 600, true);
}
add_action('init', 'rtech_tiny_image_size');

function rtech_tiny_assets_manage(){
 wp_enqueue_style('rtechwpslider-css', '//cdnjs.cloudflare.com/ajax/libs/tiny-slider/2.9.4/tiny-slider.css',null,'1.0');
 wp_enqueue_script('rtechwpslider-js', '//cdnjs.cloudflare.com/ajax/libs/tiny-slider/2.9.2/min/tiny-slider.js',null,'1.0',true);
 wp_enqueue_script('rtechwpslider-main-js', plugin_dir_url(__FILE__)."/assets/js/rtech-main.js",array('jquery'),'1.0',true);

}
add_action('wp_enqueue_scripts', 'rtech_tiny_assets_manage');

function rtech_tiny_shortcode_slider( $arguments, $content ){
    $defaults = array(
        'width' =>800,
        'height' =>600,
        'id' => '',
    );
    $attributes = shortcode_atts( $defaults, $arguments );
    $content = do_shortcode( $content );
    $shortcode_output = <<<EOD
      <div id="{$attributes['id']}" style="width: {$attributes['width']}; height: {$attributes['height']}">
       <div class="slider">
          {$content}
       </div>
      </div>
EOD;

    return $shortcode_output;

}
add_shortcode('rtech_tslider', 'rtech_tiny_shortcode_slider');

function rtech_tiny_shortcode_slide( $arguments ){
    $defaults = array(
        'caption' => '',
        'id' => '',
        'size' => 'rtech-slider-image-size',
    );
    $attributes = shortcode_atts( $defaults, $arguments );
    $image_src = wp_get_attachment_image_src( $attributes['id'], $attributes['size'] );
    $shortcode_output = <<<EOD
       <div class="slide">
          <p><img src="{$image_src['0']}" alt="{$attributes['caption']}"/></p>
          <p>{$attributes['caption']}</p>
       </div>
EOD;

    return $shortcode_output;
}
add_shortcode('rtech_tslide', 'rtech_tiny_shortcode_slide');