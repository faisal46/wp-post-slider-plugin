;(function($) {
    $(document).ready(function() {

        var slider = tns({
            container: '.slider',
            items: 2,
            slideBy: 'page',
            autoplay: true,
            controls: false,
            nav: false,
        });

    });
})(jQuery);